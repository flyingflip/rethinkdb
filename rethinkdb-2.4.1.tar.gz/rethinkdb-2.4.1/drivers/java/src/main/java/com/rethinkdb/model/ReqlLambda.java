package com.rethinkdb.model;

public interface ReqlLambda {

}
